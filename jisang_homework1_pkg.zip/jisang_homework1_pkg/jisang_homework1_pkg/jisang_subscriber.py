
import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class JisangSubscriber(Node):
    def __init__(self):
        super().__init__('JisangSubscriber')
        self.subscription = self.create_subscription(
            String,
            'JisangTopic',
            self.listener_callback,
            10
        )

    def listener_callback(self, msg):
        self.get_logger().info(f'Received: "{msg.data}"')


def main(args=None):
    rclpy.init(args=args)
    node = JisangSubscriber()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

