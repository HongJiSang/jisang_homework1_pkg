import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class JisangPublisher(Node):
    def __init__(self):
        super().__init__('JisangPublisher')
        self.publisher_ = self.create_publisher(String, 'JisangTopic', 10)
        self.timer = self.create_timer(1.0, self.timer_callback)
        self.i = 0


    def timer_callback(self):
        msg = String()
        # string, integer, float64 형태를 모두 포함하는 데이터 포맷
        msg.data = f"Jisang Text, Int: {self.i}, Float: {float(self.i) * 1.5}"
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: "{msg.data}"')
        self.i += 1

def main(args=None):
    rclpy.init(args=args)
    node = JisangPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()


