from setuptools import setup

package_name = 'jisang_homework1_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jwoo',
    maintainer_email='jwoo@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'jisang_publisher = jisang_homework1_pkg.jisang_publisher:main',
            'jisang_subscriber = jisang_homework1_pkg.jisang_subscriber:main',
        ],
    },
)
