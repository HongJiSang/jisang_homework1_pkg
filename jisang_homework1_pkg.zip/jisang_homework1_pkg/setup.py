from setuptools import setup

package_name = 'jisang_homework1_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='홍지상',
    maintainer_email='jwoo@example.com',
    description='홍지상 homework 1 publisher and subscriber',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'jisang_publisher = jisang_homework1_pkg.jisang_publisher:main',
            'jisang_subscriber = jisang_homework1_pkg.jisang_subscriber:main',
        ],
    },
)

